﻿Imports System.IO

Public Class Form1
    Dim grades(9, 2) As Integer
    Dim studentCounter As Integer = 0
    Dim fileName As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ListBox1.Items.Add(vbTab & vbTab & "Test 1" & vbTab & "Test 2" & vbTab & "Test 3" & vbTab & "Average")
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub OpenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenToolStripMenuItem.Click
        Dim result As DialogResult

        Using fileChooser As New OpenFileDialog()
            result = fileChooser.ShowDialog()
            fileName = fileChooser.FileName

        End Using
        Records()

    End Sub
    Sub Records()
        Dim fileReader As StreamReader = Nothing
        Try
            fileReader = New StreamReader(fileName)
            Do While Not fileReader.EndOfStream
                Dim output As String = "Student " & studentCounter & vbTab
                Dim line As String = fileReader.ReadLine()
                Dim field() As String = line.Split(" "c)
                grades(studentCounter, 0) = Convert.ToInt32(field(0))
                output &= vbTab & grades(studentCounter, 0)
                grades(studentCounter, 1) = Convert.ToInt32(field(1))
                output &= vbTab & grades(studentCounter, 1)
                grades(studentCounter, 2) = Convert.ToInt32(field(2))
                output &= vbTab & grades(studentCounter, 2)
                output &= vbTab & CalculateStudentAverage(studentCounter)
                ListBox1.Items.Add(output)


                Label3.Text = CalculateStudentAverage()
                studentCounter += 1








            Loop
            DispalyBarChart()
        Catch ex As Exception
            MessageBox.Show("Failed to read File", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If fileReader IsNot Nothing Then
                Try
                    fileReader.Close()
                Catch ex As Exception
                    MessageBox.Show("Failed to close File", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                End Try

            End If
        End Try
    End Sub

    Sub DispalyBarChart()
        ListBox2.Items.Clear()

        Dim frequency(10) As Integer

        For row = 0 To studentCounter - 1
            For column = 0 To grades.GetUpperBound(1)
                frequency(grades(row, column) \ 10) += 1

            Next column
        Next row

        For count = 0 To frequency.GetUpperBound(0)
            Dim bar As String

            If count = 10 Then
                bar = String.Format("{0,5:D}:", 100)
            Else
                bar = String.Format("{0,2:D2}-{1,2:D2}:", count * 10, count * 10 + 9)

            End If

            For stars = 1 To frequency(count)
                bar &= ("*")
            Next
            ListBox2.Items.Add(bar)
        Next count

    End Sub

    Function CalculateClassAverage(row As Integer) As String

        Dim gradetotal As Integer = 0

        For column = 0 To grades.GetUpperBound(1)
            gradetotal += grades(row, column)
        Next

        Dim studenAverage As String = String.Empty
        studenAverage = String.Format("{0:F}", (gradetotal / (grades.GetUpperBound(1) + 1)))

        Return studenAverage



    End Function

    Function CalculateStudentAverage() As String

        Dim classtotal As Integer = 0

        For row = 0 To studentCounter - 1
            For column = 0 To grades.GetUpperBound(1)
                classtotal += grades(row, column)

            Next column

        Next row

        Dim classAverage As String = String.Empty
        classAverage = String.Format("{0:F}", (classtotal / (studentCounter * (grades.GetUpperBound(1) + 1))))

        Return classAverage
    End Function
End Class
