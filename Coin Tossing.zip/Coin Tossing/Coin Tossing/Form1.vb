﻿Public Class Form1

    Dim randomObject As New Random()
    Dim randomNumber As Integer
    Dim heads As Integer = 0
    Dim tails As Integer = 0
    Dim total As Integer = 0


    Private Sub TossButton_Click(sender As Object, e As EventArgs) Handles TossButton.Click
        displayToss(toss1)
        'displayToss(toss2)

        total += 2

        TextBox1.Text = "Result " & vbTab & "Frequency " & vbTab & "Percent" & vbCrLf &
            "Heads" & vbTab & heads & vbTab & vbTab & String.Format("{0:P}", heads / total) & vbCrLf &
            "Tails" & vbTab & tails & vbTab & vbTab & String.Format("{0:P}", tails / total)


    End Sub

    Sub displayToss(tossPictureBox As PictureBox)
        Dim h As Integer = randomObject.Next(1, 3)
        Dim pictureResource = My.Resources.ResourceManager.GetObject(String.Format("toss{0}", h))

        tossPictureBox.Image = CType(pictureResource, Image)

        Select Case h
            Case 1
                Label1.Text = "True"
                heads += 1

            Case Else
                Label1.Text = "False"
                tails += 1
        End Select
        'End Sub


        'Dim randomObject As New Random()
        'Dim headscount As Integer
        'Dim tailscount As Integer

        'Private Sub tossButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TossButton.Click

        '    Dim count As Integer
        '    Dim flip As Integer
        '    Dim intrandomGenerator As New Random
        '    Dim heads As Integer
        '    Dim tails As Integer

        '    tails = 0
        '    heads = 0

        '    flip = intrandomGenerator.Next(0, 2)

        '    If flip = 0 Then
        '        tailscount += 1
        '        TextBox1.Text = "False"
        '    Else
        '        headscount += 1
        '        TextBox1.Text = "True"
        '    End If

        '    count = count + 1

        '    TextBox2.Text += CStr(headscount)
        '    TextBox2.Text += CStr(tailscount)

        'End Sub


        '' get a random coin image
        'Sub DisplayCoin(ByVal coinPictureBox As PictureBox)

        '    ' generate random integer in range 0 to 1
        '    Dim coin As Integer = randomObject.Next(0, 2)

        '    ' retrieve specific coin image from resources
        '    Dim pictureResource = My.Resources.ResourceManager.GetObject(
        '       String.Format("coin{0}", coin))

        '    ' convert pictureResource to type Image and display in PictureBox
        '    coinPictureBox.Image = CType(pictureResource, Image)
    End Sub

End Class
