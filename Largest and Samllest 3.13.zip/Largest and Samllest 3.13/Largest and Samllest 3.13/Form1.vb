﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim sale1, sale2, sale3 As Integer

        sale1 = TextBox1.Text

        sale2 = TextBox2.Text

        sale3 = TextBox3.Text


        Dim largest As Integer = sale1

        If (sale2 > largest) Then
            largest = sale2
        End If
        If (sale3 > largest) Then
            largest = sale3

        End If


        TextBox5.AppendText(largest)
        Dim smallest As Integer = sale1
        If (sale2 < smallest) Then
            smallest = sale2
        End If

        If (sale3 < smallest) Then smallest = sale3

        TextBox4.AppendText(smallest)
    End Sub
End Class
