﻿Public Class Form1

    ' Jared M Kodero 

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim minutesParked As Integer = Convert.ToInt32(TextBox1.Text)
        Dim parkingFees As Integer = 0
        Dim additionalFees As Integer = 0
        Dim days As Integer = minutesParked / (60 * 24)


        If minutesParked < 0 Then
            MessageBox.Show("Enter valid time!", "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error)
        End If



        If minutesParked > 30 Then

            minutesParked -= (days * 24 * 60)

            parkingFees = 24 * days
        End If




        If minutesParked > 30 Then
            minutesParked -= 60
            additionalFees += 2

            While minutesParked > 0
                additionalFees += 1
                minutesParked -= 30
            End While

            If additionalFees > 24 Then
                additionalFees = 24
            End If

            parkingFees += additionalFees

        End If

        pricingtxt.Text = "Your Charge is " & String.Format("{0:C}", parkingFees)

    End Sub

   
    




End Class
