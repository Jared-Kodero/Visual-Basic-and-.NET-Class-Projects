﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label5.Text = (Val(TextBox1.Text) + Val(TextBox2.Text) + Val(TextBox3.Text)) / 3
    End Sub
    Private Sub TextBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox1.MouseDown
        TextBox1.Clear()

    End Sub
    Private Sub TextBox2_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox2.MouseDown
        TextBox2.Clear()


    End Sub
    Private Sub TextBox3_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox3.MouseDown
        TextBox3.Clear()
    End Sub

End Class
