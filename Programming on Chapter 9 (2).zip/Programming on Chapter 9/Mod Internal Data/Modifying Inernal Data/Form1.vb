﻿'///////Jared M Kodero
Public Class TimeTest
    Dim time As New Time()

    Private Sub updateDisplay()

        hourBox.Text = time.Seconds \ 3600 Mod 24

        minuteBox.Text = (time.Seconds Mod 3600) \ 60

        secondBox.Text() = ((time.Seconds Mod 3600) Mod 60)

        output1Label.Text = "Hour:" & (time.Seconds \ 3600) Mod 24 & "; Minute:" &
            (time.Seconds Mod 3600) \ 60 & ";Second:" &
            ((time.Seconds Mod 3600) Mod 60)

        output2Label.Text = "Standard time is:" & time.ToString() & "; Universal Time is:" &
            time.ToUniversalString()

    End Sub


    Private Sub setTimeButton_Click(sender As Object, e As EventArgs) Handles setTimeButton.Click
        Dim h, m, s As Integer

        If hourBox.Text <> String.Empty Then
            h = Convert.ToInt32(hourBox.Text)
        End If

        If minuteBox.Text <> String.Empty Then
            m = Convert.ToInt32(minuteBox.Text)
        End If

        If secondBox.Text <> String.Empty Then
            h = Convert.ToInt32(secondBox.Text)
        End If

        Try
            time.setTime(s, m, h)
        Catch ex As ArgumentOutOfRangeException

            MessageBox.Show("The hour, minute or second" & "was out of range", "Out of Range",
            MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try

        updateDisplay()
    End Sub

    Private Sub incrementSecondButton_Click(sender As Object, e As EventArgs) Handles incrementSecondButton.Click
        time.Tick()
        updateDisplay()
    End Sub

    Private Sub incrementMinuteButton_Click(sender As Object, e As EventArgs) Handles incrementMinuteButton.Click
        time.incrementMinute()
        updateDisplay()
    End Sub

    Private Sub incrementHourButton_Click(sender As Object, e As EventArgs) Handles incrementHourButton.Click
        time.incrementHour()
        updateDisplay()
    End Sub

End Class
