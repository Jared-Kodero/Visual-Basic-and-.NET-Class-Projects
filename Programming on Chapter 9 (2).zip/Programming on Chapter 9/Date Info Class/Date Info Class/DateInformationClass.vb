﻿Public Class DateInformationClass
    Dim _month, _day, _year As Integer
    Public Sub New()
        Month = 1
        Day = 1
        Year = 1901


    End Sub

    Public Property Month() As Integer
        Get
            Return _month

        End Get
        Set(value As Integer)
            If value < 1 Or value > 12 Then
                Throw New System.Exception("Invalid Date")
            Else
                _month = value

            End If
        End Set
    End Property

    Public Property Year() As Integer
        Get
            Return _year

        End Get
        Set(value As Integer)

            If value < 0 Then
                Throw New System.Exception("Invalid Date")
            Else
                _year = value
            End If
        End Set
    End Property

    Public Property Day() As Integer
        Get
            Return _day

        End Get
        Set(value As Integer)
            If (_year Mod 4 = 0 And _year Mod 100 <> 0) Or _year Mod 400 = 0 Then
                If _month = 2 Then
                    If value < 11 Or value > 29 Then
                        Throw New System.Exception("Invalid Date")
                    End If
                Else
                    Select Case _month
                        Case 1, 3, 5, 7, 8, 10, 12
                            If value > 31 Or value < 1 Then
                                Throw New System.Exception("Invalid Date")

                            End If

                    End Select
                End If
            Else
                If _month = 2 Then
                    If value < 1 Or value > 28 Then
                        Throw New System.Exception("Invalid Date")
                    End If
                Else
                    Select Case _month
                        Case 1, 3, 5, 7, 8, 10, 12

                            If value > 31 Or value < 1 Then
                                Throw New System.Exception("Invalid Date")
                            End If
                        Case 4, 6, 9, 11
                            If value > 30 Or value < 1 Then
                                Throw New System.Exception("Invalid Date")

                            End If
                    End Select
                End If
            End If
            _day = value
        End Set
    End Property
    Public Overrides Function ToString() As String
        Return Month & "/" & Day & "/" & Year
    End Function


End Class
