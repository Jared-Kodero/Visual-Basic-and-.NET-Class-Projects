﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox1.Text <> String.Empty AndAlso TextBox2.Text <> String.Empty Then

            Dim futureValue As Double = Val(TextBox1.Text)
            Dim intrestRate As Double = Val(TextBox2.Text)
            Dim years As Integer = NumericUpDown1.Value

            'calculate the principal ammount to be invested

            Dim principalAmmount As Double = futureValue / ((1 + intrestRate / 100) ^ years)

            If ListBox1.Items.Count = 0 Then
                ListBox1.Items.Add("Year" & vbTab & "Investment needed" & vbCrLf)
            End If

            ListBox1.Items.Add(years & vbTab & String.Format("${0:F}", principalAmmount) & vbCrLf)



        End If
    End Sub
End Class
