﻿Public Class Form1
    Dim pCount As Integer = 0
    Dim fCount As Integer = 0


    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If (TextBox1.Text <> String.Empty) Then
            ListBox1.Items.Add(TextBox1.Text)
            If (TextBox1.Text = "P") Then
                pCount += 1
            ElseIf (TextBox1.Text = "F") Then
                fCount += 1


            En d If

                If (pCount + fCount) >= 10 Then
                    TextBox1.Enabled = False
                    Button1.Enabled = False
                    Button2.Enabled = False
                    TextBox1.Text = " "
                    TextBox1.Focus()


                End If



            End If
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click
        Label3.Text = "Pass: " & pCount & vbCrLf _
            & "Fail: "
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If (pCount > 8) Then

            Label3.Text = "Pass: " & pCount
        End If
    End Sub
End Class
