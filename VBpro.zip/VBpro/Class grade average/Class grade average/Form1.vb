﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim grade As Integer = Val(TextBox1.Text)
        If TextBox1.Text <> String.Empty Then
            ListBox1.Items.Add(grade)
            Button2.Enabled = True


        End If
        TextBox1.Clear()

        TextBox1.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim total As Integer = 0
        Dim average As Double
        Dim studentCounter As Integer = 0

        While (studentCounter < ListBox1.Items.Count)
            total += ListBox1.Items(studentCounter)
            studentCounter += 1

        End While

        If studentCounter = 0 Then
            Label3.Text = "No grades were entered."
        Else
            average = total / ListBox1.Items.Count
            Label3.Text = "Total of " & studentCounter & " grade(s) is " & total & "." &
 " Class average is " & average
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListBox1.Items.Clear()
        TextBox1.Clear()
        TextBox1.Focus()
    End Sub
End Class
