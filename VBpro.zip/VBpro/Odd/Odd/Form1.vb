﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.AppendText("n" & vbTab & "n^2" & vbTab & "n^3")

        Dim counter As Integer = 1
        While (counter <= 5)
            TextBox1.AppendText(vbCrLf & counter & vbTab & counter ^ 2 & vbTab & counter ^ 3)
            counter += 1
        End While

    End Sub
End Class
