﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim total As Integer = 0
        Dim counter As Integer

        Do While (counter <= 10)
            total = total + counter
            counter = counter + 1
        Loop

        Label1.Text = "Sum of 1 to 10 is " & total


    End Sub
End Class
