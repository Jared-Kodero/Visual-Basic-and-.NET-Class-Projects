﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Declare variables

        Dim firstname As String
        Dim lastname As String

        firstname = TextBox1.Text
        lastname = TextBox2.Text

        Label3.Text = firstname + " " + lastname


    End Sub
End Class
