﻿Public Class Form1


    'Jared M Kodero
    'Project
    'ISBN Calculator


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox1.Text = String.Empty Then
            MessageBox.Show("Enter 13 Digit ISBN!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

        Dim ISBN As String = TextBox1.Text


        Dim sum = 0

        For i = 0 To ISBN.Length - 1

            Dim digit = Asc(ISBN.Chars(i)) - Asc("0"c)
            If i Mod 2 <> 0 Then
                sum += digit * 3
            Else
                sum += digit
            End If

        Next

        ISBN = ((10 - sum Mod 10) Mod 10).ToString









        'Dim Position As Integer
        'Dim lastPosition As Integer



        'Position = Convert.ToInt32(ISBN.Substring(0, 1)) * 1
        'Position = Position + Convert.ToInt32(ISBN.Substring(1, 1)) * 3
        'Position = Position + Convert.ToInt32(ISBN.Substring(2, 1)) * 1
        'Position = Position + Convert.ToInt32(ISBN.Substring(3, 1)) * 3
        'Position = Position + Convert.ToInt32(ISBN.Substring(4, 1)) * 1
        'Position = Position + Convert.ToInt32(ISBN.Substring(5, 1)) * 3
        'Position = Position + Convert.ToInt32(ISBN.Substring(6, 1)) * 1
        'Position = Position + Convert.ToInt32(ISBN.Substring(7, 1)) * 3
        'Position = Position + Convert.ToInt32(ISBN.Substring(8, 1)) * 1
        'Position = Position + Convert.ToInt32(ISBN.Substring(9, 1)) * 3
        'Position = Position + Convert.ToInt32(ISBN.Substring(10, 1)) * 1
        'Position = Position + Convert.ToInt32(ISBN.Substring(11, 1)) * 3
        'lastPosition = 10 - (Position Mod 10)

        If lastPosition = Convert.ToInt32(ISBN.Substring(12, 1)) Then
            MessageBox.Show("Number is valid!", "Correct", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Else
            MessageBox.Show("Number is invalid!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If




    End Sub





























End Class
