﻿Public Class Form1


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim first As Integer
        Dim second As Integer
        Dim result As Integer

        first = Val(TextBox1.Text) 'assign first value'
        second = Val(TextBox2.Text) 'assign second value'

        'Getting result'
        result = first Mod second

        If (result.Equals(0)) Then

            Label3.Text = TextBox1.Text + " is a multiple of " + TextBox2.Text
        Else
            Label3.Text = TextBox1.Text + " is not a multiple of " + TextBox2.Text




        End If



    End Sub

    





End Class
