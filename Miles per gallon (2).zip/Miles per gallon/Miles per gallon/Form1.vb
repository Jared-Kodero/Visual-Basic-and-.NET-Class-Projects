﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim milesDriven As Double = milesDrivenTextBox.Text
        Dim gallonsUsed As Double = gallonsUsedTextBox.Text
        ' if gallons used > 0 then calculate

        If (gallonsUsed > 0) Then
            Dim milesPerGallon As Double = milesDriven / gallonsUsed

            'add miles to milesListbox
            milesListBox.Items.Add(String.Format("{0:F}", milesDriven))

            'add gallons to gallons list box
            gallonsListBox.Items.Add(String.Format("{0:F}", gallonsUsed))

            'add mpg to mpg list box
            mpgListBox.Items.Add(String.Format("{0:F}", milesPerGallon))

            'declearing variables for computing totals
            Dim inputCounter As Integer = 0
            Dim totalMiles As Double = 0
            Dim totalGallons As Double = 0
            Dim totalAverage As Double = 0
            Dim current As Double

            'calculate total miles and gallons used
            Do While inputCounter < milesListBox.Items.Count

                'get current miles

                current = gallonsListBox.Items(inputCounter)

                'add to the gallons used 

                totalGallons += current

                'increment counter variable
                inputCounter += 1

            Loop

            'Average
            totalAverage = totalMiles / totalGallons


            '\\ display in result label
            totalResutsLabel.Text = "Total miles driven: " & String.Format("{0:F}", totalMiles) & vbCrLf & "Total gallons used: " & String.Format("{0:F}", totalGallons) & vbCrLf & "Total MPG: " & String.Format("{0:F}", totalAverage)

            'clear text boxes
            milesDrivenTextBox.Text = String.Empty
            gallonsUsedTextBox.Text = String.Empty

        Else

            totalResutsLabel.Text = "Gallons used must be " & "greater than 0!)"
            gallonsUsedTextBox.Text = String.Empty
            gallonsUsedTextBox.Focus()


        End If
    End Sub
End Class


