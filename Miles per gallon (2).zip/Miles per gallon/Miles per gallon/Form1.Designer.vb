﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.totalResutsLabel = New System.Windows.Forms.Label()
        Me.milesDrivenTextBox = New System.Windows.Forms.TextBox()
        Me.gallonsUsedTextBox = New System.Windows.Forms.TextBox()
        Me.milesListBox = New System.Windows.Forms.ListBox()
        Me.gallonsListBox = New System.Windows.Forms.ListBox()
        Me.mpgListBox = New System.Windows.Forms.ListBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter miles driven:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 60)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(122, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter gallons usd:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(9, 173)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Miles:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(111, 173)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Gallons:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(228, 173)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "MPG:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 324)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Totals:"
        '
        'totalResutsLabel
        '
        Me.totalResutsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.totalResutsLabel.Location = New System.Drawing.Point(12, 341)
        Me.totalResutsLabel.Name = "totalResutsLabel"
        Me.totalResutsLabel.Size = New System.Drawing.Size(300, 98)
        Me.totalResutsLabel.TabIndex = 6
        '
        'milesDrivenTextBox
        '
        Me.milesDrivenTextBox.Location = New System.Drawing.Point(162, 13)
        Me.milesDrivenTextBox.Name = "milesDrivenTextBox"
        Me.milesDrivenTextBox.Size = New System.Drawing.Size(150, 22)
        Me.milesDrivenTextBox.TabIndex = 7
        '
        'gallonsUsedTextBox
        '
        Me.gallonsUsedTextBox.Location = New System.Drawing.Point(162, 60)
        Me.gallonsUsedTextBox.Name = "gallonsUsedTextBox"
        Me.gallonsUsedTextBox.Size = New System.Drawing.Size(150, 22)
        Me.gallonsUsedTextBox.TabIndex = 8
        '
        'milesListBox
        '
        Me.milesListBox.FormattingEnabled = True
        Me.milesListBox.ItemHeight = 16
        Me.milesListBox.Location = New System.Drawing.Point(12, 193)
        Me.milesListBox.Name = "milesListBox"
        Me.milesListBox.Size = New System.Drawing.Size(68, 100)
        Me.milesListBox.TabIndex = 9
        '
        'gallonsListBox
        '
        Me.gallonsListBox.FormattingEnabled = True
        Me.gallonsListBox.ItemHeight = 16
        Me.gallonsListBox.Location = New System.Drawing.Point(114, 193)
        Me.gallonsListBox.Name = "gallonsListBox"
        Me.gallonsListBox.Size = New System.Drawing.Size(79, 100)
        Me.gallonsListBox.TabIndex = 10
        '
        'mpgListBox
        '
        Me.mpgListBox.FormattingEnabled = True
        Me.mpgListBox.ItemHeight = 16
        Me.mpgListBox.Location = New System.Drawing.Point(231, 193)
        Me.mpgListBox.Name = "mpgListBox"
        Me.mpgListBox.Size = New System.Drawing.Size(81, 100)
        Me.mpgListBox.TabIndex = 11
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(162, 104)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(150, 35)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Calculate MPG"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(334, 452)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.mpgListBox)
        Me.Controls.Add(Me.gallonsListBox)
        Me.Controls.Add(Me.milesListBox)
        Me.Controls.Add(Me.gallonsUsedTextBox)
        Me.Controls.Add(Me.milesDrivenTextBox)
        Me.Controls.Add(Me.totalResutsLabel)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents totalResutsLabel As System.Windows.Forms.Label
    Friend WithEvents milesDrivenTextBox As System.Windows.Forms.TextBox
    Friend WithEvents gallonsUsedTextBox As System.Windows.Forms.TextBox
    Friend WithEvents milesListBox As System.Windows.Forms.ListBox
    Friend WithEvents gallonsListBox As System.Windows.Forms.ListBox
    Friend WithEvents mpgListBox As System.Windows.Forms.ListBox
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
