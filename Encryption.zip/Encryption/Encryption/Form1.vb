﻿Public Class Form1

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text.Length = 4 Then
            Dim Key As Integer = TextBox1.Text

            'extract last digit
            Dim firstDigit As Integer = Key Mod 10
            Key /= 10

            'extract second digit from right
            Dim secondDigit As Integer = Key Mod 10
            Key /= 10

            'extract third digit from right
            Dim thirdDigit As Integer = Key Mod 10
            Key /= 10

            'extract next digit
            Dim fourthDigit As Integer = Key Mod 10

            'Encryption process
            firstDigit = (firstDigit + 7) Mod 10
            secondDigit = (secondDigit + 7) Mod 10
            thirdDigit = (thirdDigit + 7) Mod 10
            fourthDigit = (fourthDigit + 7) Mod 10

            'dispaly result
            Label2.Text = "Encrypted number is " + secondDigit.ToString + firstDigit.ToString + fourthDigit.ToString + thirdDigit.ToString


        End If
    End Sub
End Class
