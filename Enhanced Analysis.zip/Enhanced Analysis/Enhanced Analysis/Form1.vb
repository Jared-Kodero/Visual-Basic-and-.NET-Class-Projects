﻿Public Class Form1

    Dim counter As Integer = 0


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (resultListBox.Items.Count < 10) Then
            'add grades to the end of resultListBox 
            If (resultTextBox.Text = "P" Or
               resultTextBox.Text = "p" Or
               resultTextBox.Text = "F" Or
               resultTextBox.Text = "f") Then
                resultListBox.Items.Add(resultTextBox.Text)
            Else
                counter += 1

            End If

            resultTextBox.Clear()
            resultTextBox.Focus()
        End If

        If resultListBox.Items.Count = 10 Then
            Button1.Enabled = False
            resultTextBox.Enabled = False
            Button2.Enabled = True
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'initialize variables
        Dim passes As Integer = 0
        Dim failures As Integer = 0
        Dim student As Integer = 0
        Dim result As String

        'process 10 students using counter controlled loop

        Do While student < 10
            result = resultListBox.Items(student) ' get result

            'nested control statement

            If result = "P" Or result = "p" Then
                passes += 1
            Else : failures += 1
            End If

            student += 1

        Loop

        'Display  exam result

        analysisResultsLabel.Text = "Passed: " & passes & vbCrLf & "Failed: " & failures & vbCrLf
        'raise tution if more than 8 students pass

        If passes > 8 Then
            analysisResultsLabel.Text &= "Bonus to instructor!"
        End If



    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        resultListBox.Items.Clear()
        analysisResultsLabel.Text = String.Empty
        Button1.Enabled = True
        resultTextBox.Enabled = True
        Button2.Enabled = False
        resultTextBox.Focus()



    End Sub
End Class
