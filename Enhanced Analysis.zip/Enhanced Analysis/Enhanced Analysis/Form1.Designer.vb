﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.resultListBox = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.resultTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.analysisResultsLabel = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'resultListBox
        '
        Me.resultListBox.FormattingEnabled = True
        Me.resultListBox.ItemHeight = 16
        Me.resultListBox.Location = New System.Drawing.Point(12, 52)
        Me.resultListBox.Name = "resultListBox"
        Me.resultListBox.Size = New System.Drawing.Size(101, 356)
        Me.resultListBox.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 17)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Results:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(203, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(191, 17)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Enter P for Pass or F for Fail:"
        '
        'resultTextBox
        '
        Me.resultTextBox.Location = New System.Drawing.Point(407, 32)
        Me.resultTextBox.Name = "resultTextBox"
        Me.resultTextBox.Size = New System.Drawing.Size(100, 22)
        Me.resultTextBox.TabIndex = 11
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(206, 71)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(301, 42)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Submit Button"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Enabled = False
        Me.Button2.Location = New System.Drawing.Point(206, 134)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(301, 41)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Analyze Result"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(203, 213)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 17)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Analysis"
        '
        'analysisResultsLabel
        '
        Me.analysisResultsLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.analysisResultsLabel.Location = New System.Drawing.Point(206, 230)
        Me.analysisResultsLabel.Name = "analysisResultsLabel"
        Me.analysisResultsLabel.Size = New System.Drawing.Size(301, 119)
        Me.analysisResultsLabel.TabIndex = 15
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(206, 368)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(301, 40)
        Me.Button3.TabIndex = 16
        Me.Button3.Text = "Clear Result"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(519, 451)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.analysisResultsLabel)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.resultTextBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.resultListBox)
        Me.Name = "Form1"
        Me.Text = "Enhanced Analysis"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents resultListBox As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents resultTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents analysisResultsLabel As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button

End Class
