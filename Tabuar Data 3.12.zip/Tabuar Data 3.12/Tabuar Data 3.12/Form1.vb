﻿Public Class Form1

    Public Const vbTab As String = "      "
    Public Const vbTab1 As String = "     "


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer
        TextBox1.TextAlign = HorizontalAlignment.Left
        TextBox1.AppendText("number " & "square " & "cube ")

        'Loop'
        For i = 0 To 5

            If i < 4 Then
                TextBox1.AppendText(vbCrLf & i & vbTab & i * i & vbTab & i * i * i)

            Else
                TextBox1.AppendText(vbCrLf & i & vbTab & i * i & vbTab1 & i * i * i)



            End If

            'next to loop
        Next



    End Sub
End Class
