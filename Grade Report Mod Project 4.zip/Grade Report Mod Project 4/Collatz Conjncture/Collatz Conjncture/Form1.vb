﻿Public Class Form1

    Dim number As Integer
    Dim even As Integer
    Dim counter As Integer

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        number = TextBox1.Text
        counter = 1
        While number <> 1
            even = number Mod 2
            If even = 0 Then
                number = number / 2
                counter = counter + 1
            Else
                number = number * 3 + 1
                counter = counter + 1
            End If
            TextBox2.AppendText(number & " ")
        End While
        TextBox2.AppendText(vbCrLf & "Number of terms:" & counter)
    End Sub


   
   
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = String.Empty
        TextBox2.Text = String.Empty
    End Sub
End Class
