﻿Public Class Form1

    'Jared M Kodero

    Dim var(3, 3) As Integer
    Dim counter As Integer = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        PictureBox1.Image = Nothing
        PictureBox2.Image = Nothing
        PictureBox3.Image = Nothing
        PictureBox4.Image = Nothing
        PictureBox5.Image = Nothing
        PictureBox6.Image = Nothing
        PictureBox7.Image = Nothing
        PictureBox8.Image = Nothing
        PictureBox9.Image = Nothing
        PictureBox1.Enabled = True
        PictureBox2.Enabled = True
        PictureBox3.Enabled = True
        PictureBox4.Enabled = True
        PictureBox5.Enabled = True
        PictureBox6.Enabled = True
        PictureBox7.Enabled = True
        PictureBox8.Enabled = True
        PictureBox9.Enabled = True
        Label1.Text = String.Empty

        Dim i As Integer
        Dim j As Integer
        For i = 0 To 2 Step 1
            For j = 0 To 2 Step 1
                var(i, j) = 0
            Next
        Next

    End Sub

  
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load




        Dim i As Integer
        Dim j As Integer
        For i = 0 To 2 Step 1
            For j = 0 To 2 Step 1
                var(i, j) = 0
            Next


        Next
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox1.Image = My.Resources.O
            var(0, 0) = 2

        Else
            PictureBox1.Image = My.Resources.X
            var(0, 0) = 1

        End If
        PictureBox1.Enabled = False
        CheckResult()


    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox2.Image = My.Resources.O
            var(0, 1) = 2

        Else
            PictureBox2.Image = My.Resources.X
            var(0, 1) = 1

        End If
        PictureBox2.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox3.Image = My.Resources.O
            var(0, 2) = 2

        Else
            PictureBox3.Image = My.Resources.X
            var(0, 2) = 1

        End If
        PictureBox3.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox4.Image = My.Resources.O
            var(1, 0) = 2

        Else
            PictureBox4.Image = My.Resources.X
            var(1, 0) = 1

        End If
        PictureBox4.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox5.Image = My.Resources.O
            var(1, 1) = 2

        Else
            PictureBox5.Image = My.Resources.X
            var(1, 1) = 1

        End If
        PictureBox5.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox6.Image = My.Resources.O
            var(1, 2) = 2

        Else
            PictureBox6.Image = My.Resources.X
            var(1, 2) = 1

        End If
        PictureBox6.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox7.Image = My.Resources.O
            var(2, 0) = 2

        Else
            PictureBox7.Image = My.Resources.X
            var(2, 0) = 1

        End If
        PictureBox7.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox8.Image = My.Resources.O
            var(2, 1) = 2

        Else
            PictureBox8.Image = My.Resources.X
            var(2, 1) = 1

        End If
        PictureBox8.Enabled = False
        CheckResult()
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        counter = counter + 1
        If counter Mod 2 = 0 Then
            PictureBox9.Image = My.Resources.O
            var(2, 2) = 2

        Else
            PictureBox9.Image = My.Resources.X
            var(2, 2) = 1

        End If
        PictureBox9.Enabled = False
        CheckResult()
    End Sub

    Sub CheckResult()
        Dim i As Integer
        Dim flag As Integer = 0
        If counter > 4 Then
            For i = 1 To 2 Step 1
                If var(0, 0) = i And var(0, 1) = i And var(0, 2) = i Then

                    flag += 1
                    Exit For
                ElseIf var(1, 0) = i And var(1, 1) = i And var(1, 2) = i Then

                    flag += 1
                    Exit For
                ElseIf var(2, 0) = i And var(2, 1) = i And var(2, 2) = i Then

                    flag += 1
                    Exit For
                ElseIf var(0, 0) = i And var(1, 0) = i And var(2, 0) = i Then

                    flag += 1
                    Exit For
                ElseIf var(0, 1) = i And var(1, 1) = i And var(2, 1) = i Then

                    flag += 1
                    Exit For
                ElseIf var(0, 2) = i And var(1, 2) = i And var(2, 2) = i Then

                    flag += 1
                    Exit For
                ElseIf var(0, 0) = i And var(1, 1) = i And var(2, 2) = i Then

                    flag += 1
                    Exit For
                ElseIf var(0, 2) = i And var(1, 1) = i And var(2, 0) = i Then

                    flag += 1
                    Exit For
                End If
            Next
            If flag > 0 Then
                If i = 1 Then
                    Player1Won()
                ElseIf i = 2 Then
                    Player2Won()
                End If
            End If
            If flag = 0 And counter = 9 Then
                Label1.Text = "No Result..."
            End If
        End If

    End Sub

    Sub Player1Won()
        Label1.Text = "Player X Won!!"
        PictureBox1.Enabled = False
        PictureBox2.Enabled = False
        PictureBox3.Enabled = False
        PictureBox4.Enabled = False
        PictureBox5.Enabled = False
        PictureBox6.Enabled = False
        PictureBox7.Enabled = False
        PictureBox8.Enabled = False
        PictureBox9.Enabled = False
    End Sub

    Sub Player2Won()
        Label1.Text = "Player O Won!! ..."
        PictureBox1.Enabled = False
        PictureBox2.Enabled = False
        PictureBox3.Enabled = False
        PictureBox4.Enabled = False
        PictureBox5.Enabled = False
        PictureBox6.Enabled = False
        PictureBox7.Enabled = False
        PictureBox8.Enabled = False
        PictureBox9.Enabled = False
    End Sub






End Class
