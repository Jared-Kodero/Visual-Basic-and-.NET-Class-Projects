﻿Public Class Form1

    Dim myDate As New DateInformationClass

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            myDate.Year = Convert.ToInt32(TextBox3.Text)
            myDate.Month = Convert.ToInt32(TextBox2.Text)
            myDate.Day = Convert.ToInt32(TextBox1.Text)
            Label5.Text = myDate.ToString

        Catch ex As Exception
            Label5.Text = ex.Message
        End Try
    End Sub
End Class
