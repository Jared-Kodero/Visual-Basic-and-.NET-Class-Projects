﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TimeTest
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.hourLabel = New System.Windows.Forms.Label()
        Me.minuteLabel = New System.Windows.Forms.Label()
        Me.secondLabel = New System.Windows.Forms.Label()
        Me.hourBox = New System.Windows.Forms.TextBox()
        Me.minuteBox = New System.Windows.Forms.TextBox()
        Me.secondBox = New System.Windows.Forms.TextBox()
        Me.setTimeButton = New System.Windows.Forms.Button()
        Me.incrementSecondButton = New System.Windows.Forms.Button()
        Me.incrementMinuteButton = New System.Windows.Forms.Button()
        Me.incrementHourButton = New System.Windows.Forms.Button()
        Me.output1Label = New System.Windows.Forms.Label()
        Me.output2Label = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'hourLabel
        '
        Me.hourLabel.AutoSize = True
        Me.hourLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.hourLabel.Location = New System.Drawing.Point(9, 20)
        Me.hourLabel.Name = "hourLabel"
        Me.hourLabel.Size = New System.Drawing.Size(72, 16)
        Me.hourLabel.TabIndex = 0
        Me.hourLabel.Text = "Set Hour:"
        '
        'minuteLabel
        '
        Me.minuteLabel.AutoSize = True
        Me.minuteLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.minuteLabel.Location = New System.Drawing.Point(200, 20)
        Me.minuteLabel.Name = "minuteLabel"
        Me.minuteLabel.Size = New System.Drawing.Size(84, 16)
        Me.minuteLabel.TabIndex = 1
        Me.minuteLabel.Text = "Set Minute:"
        '
        'secondLabel
        '
        Me.secondLabel.AutoSize = True
        Me.secondLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.secondLabel.Location = New System.Drawing.Point(425, 18)
        Me.secondLabel.Name = "secondLabel"
        Me.secondLabel.Size = New System.Drawing.Size(92, 16)
        Me.secondLabel.TabIndex = 2
        Me.secondLabel.Text = "Set Second:"
        '
        'hourBox
        '
        Me.hourBox.Location = New System.Drawing.Point(92, 15)
        Me.hourBox.Name = "hourBox"
        Me.hourBox.Size = New System.Drawing.Size(90, 22)
        Me.hourBox.TabIndex = 3
        '
        'minuteBox
        '
        Me.minuteBox.Location = New System.Drawing.Point(296, 17)
        Me.minuteBox.Name = "minuteBox"
        Me.minuteBox.Size = New System.Drawing.Size(115, 22)
        Me.minuteBox.TabIndex = 4
        '
        'secondBox
        '
        Me.secondBox.Location = New System.Drawing.Point(527, 15)
        Me.secondBox.Name = "secondBox"
        Me.secondBox.Size = New System.Drawing.Size(95, 22)
        Me.secondBox.TabIndex = 5
        '
        'setTimeButton
        '
        Me.setTimeButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.283186!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.setTimeButton.Location = New System.Drawing.Point(12, 70)
        Me.setTimeButton.Name = "setTimeButton"
        Me.setTimeButton.Size = New System.Drawing.Size(140, 35)
        Me.setTimeButton.TabIndex = 6
        Me.setTimeButton.Text = "Set Time"
        Me.setTimeButton.UseVisualStyleBackColor = True
        '
        'incrementSecondButton
        '
        Me.incrementSecondButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.283186!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.incrementSecondButton.Location = New System.Drawing.Point(167, 70)
        Me.incrementSecondButton.Name = "incrementSecondButton"
        Me.incrementSecondButton.Size = New System.Drawing.Size(168, 35)
        Me.incrementSecondButton.TabIndex = 7
        Me.incrementSecondButton.Text = "Add 1 to Second"
        Me.incrementSecondButton.UseVisualStyleBackColor = True
        '
        'incrementMinuteButton
        '
        Me.incrementMinuteButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.283186!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.incrementMinuteButton.Location = New System.Drawing.Point(341, 70)
        Me.incrementMinuteButton.Name = "incrementMinuteButton"
        Me.incrementMinuteButton.Size = New System.Drawing.Size(143, 35)
        Me.incrementMinuteButton.TabIndex = 8
        Me.incrementMinuteButton.Text = "Add 1 to Minute"
        Me.incrementMinuteButton.UseVisualStyleBackColor = True
        '
        'incrementHourButton
        '
        Me.incrementHourButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.283186!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.incrementHourButton.Location = New System.Drawing.Point(490, 70)
        Me.incrementHourButton.Name = "incrementHourButton"
        Me.incrementHourButton.Size = New System.Drawing.Size(144, 35)
        Me.incrementHourButton.TabIndex = 9
        Me.incrementHourButton.Text = "Add 1 to Hour"
        Me.incrementHourButton.UseVisualStyleBackColor = True
        '
        'output1Label
        '
        Me.output1Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.output1Label.Location = New System.Drawing.Point(27, 130)
        Me.output1Label.Name = "output1Label"
        Me.output1Label.Size = New System.Drawing.Size(629, 54)
        Me.output1Label.TabIndex = 10
        '
        'output2Label
        '
        Me.output2Label.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.output2Label.Location = New System.Drawing.Point(27, 203)
        Me.output2Label.Name = "output2Label"
        Me.output2Label.Size = New System.Drawing.Size(629, 65)
        Me.output2Label.TabIndex = 11
        '
        'TimeTest
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(728, 309)
        Me.Controls.Add(Me.output2Label)
        Me.Controls.Add(Me.output1Label)
        Me.Controls.Add(Me.incrementHourButton)
        Me.Controls.Add(Me.incrementMinuteButton)
        Me.Controls.Add(Me.incrementSecondButton)
        Me.Controls.Add(Me.setTimeButton)
        Me.Controls.Add(Me.secondBox)
        Me.Controls.Add(Me.minuteBox)
        Me.Controls.Add(Me.hourBox)
        Me.Controls.Add(Me.secondLabel)
        Me.Controls.Add(Me.minuteLabel)
        Me.Controls.Add(Me.hourLabel)
        Me.Name = "TimeTest"
        Me.Text = "Enhancing Class Time"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents hourLabel As System.Windows.Forms.Label
    Friend WithEvents minuteLabel As System.Windows.Forms.Label
    Friend WithEvents secondLabel As System.Windows.Forms.Label
    Friend WithEvents hourBox As System.Windows.Forms.TextBox
    Friend WithEvents minuteBox As System.Windows.Forms.TextBox
    Friend WithEvents secondBox As System.Windows.Forms.TextBox
    Friend WithEvents setTimeButton As System.Windows.Forms.Button
    Friend WithEvents incrementSecondButton As System.Windows.Forms.Button
    Friend WithEvents incrementMinuteButton As System.Windows.Forms.Button
    Friend WithEvents incrementHourButton As System.Windows.Forms.Button
    Friend WithEvents output1Label As System.Windows.Forms.Label
    Friend WithEvents output2Label As System.Windows.Forms.Label

End Class
