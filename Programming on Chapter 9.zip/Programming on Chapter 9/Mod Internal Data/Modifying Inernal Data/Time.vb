﻿

'////////////////// Jared = M = Kodero
Public Class Time
    Private _seconds As Integer

    Public Sub New(Optional sV As Integer = 0, Optional mV As Integer = 0,
                   Optional hV As Integer = 12)
        setTime(sV, mV, hV)
    End Sub

    Public Sub New(tV As Time)
        Seconds = tV.Seconds
    End Sub

    Public Sub setTime(s As Integer, m As Integer, h As Integer)
        If s < 0 Or s > 59 Then

            Throw New ArgumentOutOfRangeException("minute out of range")

        Else
            Seconds = s
        End If

        If m < 0 Or m > 59 Then
            Throw New ArgumentOutOfRangeException("minute out of range")

        Else
            Seconds = (m * 60) + Seconds
        End If

        If h < 0 Or h > 23 Then
            Throw New ArgumentOutOfRangeException("hour out of range")
        Else
            Seconds = (h * 3600) + Seconds

        End If
    End Sub

    Public Property Seconds() As Integer
        Get
            Return _seconds
        End Get
        Set(value As Integer)
            _seconds = value

        End Set
    End Property

    Public Function ToUniversalString() As String
        Dim h, m, s As Integer

        h = (Seconds \ 3600) Mod 24
        m = (Seconds Mod 3600) \ 60
        s = ((Seconds Mod 3600) Mod 60)
        Return String.Format("{0}:{1:D2}:{2:D2}", h, m, s)

    End Function

    Public Overrides Function ToString() As String
        Dim suffix As String

        Dim standardHour, h, m, s As Integer
        h = Seconds \ 3600 Mod 24
        m = (Seconds Mod 3600) \ 60
        s = ((Seconds Mod 3600) Mod 60)

        If h < 12 Then
            suffix = "AM"
        Else
            suffix = "PM"
        End If

        If (h = 12 Or h = 0) Then
            standardHour = 12
        Else
            standardHour = h Mod 12
        End If

        Return String.Format("{0}:{1:D2}:{2:D2}{3}", standardHour, m, s, suffix)

    End Function

    Public Sub Tick()
        Seconds = Seconds() + 1
    End Sub

    Public Sub incrementMinute()
        Seconds = Seconds() + 60
    End Sub

    Public Sub incrementHour()
        Seconds = Seconds() + 3600
    End Sub
End Class
