﻿Public Class DeckofCards

    Private Const NUMBER_OF_CARDS As Integer = 52


    Private deck(NUMBER_OF_CARDS - 1) As Card

    Private Shared randomNumbers As New Random()
    Private currentCard As Integer = 0

    Public Sub New()
        Static faces() As String = {"Ace", "Two", "Three", "Four", "Five",
         "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"}
        Static suits() As String = {"Hearts", "Diamonds", "Clubs", "Spades"}
        currentCard = 0

        For count = 0 To deck.GetUpperBound(0)
            deck(count) = New Card(faces(count Mod 13), suits(count \ 13))

        Next
    End Sub

    Public Sub Shuffle()
        currentCard = 0

        For first = 0 To deck.GetUpperBound(0)

            Dim second As Integer = randomNumbers.Next(NUMBER_OF_CARDS)
            Dim temp As Card = deck(first)
            deck(first) = deck(second)
            deck(second) = temp


        Next
    End Sub

    Public Function DealCard() As Card

        If currentCard <= deck.GetUpperBound(0) Then

            Dim lastCard As Integer = currentCard
            currentCard += 1
            Return deck(lastCard)

        Else
            Return Nothing

        End If

    End Function

End Class
