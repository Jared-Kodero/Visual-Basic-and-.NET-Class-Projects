﻿Public Class Card
    Private face As String
    Private suit As String

    Public Sub New(Face As String, Suit As String)

        Me.face = Face
        Me.suit = Suit
    End Sub

    Public Overrides Function ToString() As String
        Return face & "of" & suit
    End Function

End Class
