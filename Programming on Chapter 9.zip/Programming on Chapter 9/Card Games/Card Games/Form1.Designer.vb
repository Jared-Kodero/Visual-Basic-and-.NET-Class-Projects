﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CardGame
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.card5PictureBox = New System.Windows.Forms.PictureBox()
        Me.card4PictureBox = New System.Windows.Forms.PictureBox()
        Me.card3PictureBox = New System.Windows.Forms.PictureBox()
        Me.card2PictureBox = New System.Windows.Forms.PictureBox()
        Me.card1PictureBox = New System.Windows.Forms.PictureBox()
        Me.dealButton = New System.Windows.Forms.Button()
        Me.shuffleButton = New System.Windows.Forms.Button()
        CType(Me.card5PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.card4PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.card3PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.card2PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.card1PictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'card5PictureBox
        '
        Me.card5PictureBox.Location = New System.Drawing.Point(831, 124)
        Me.card5PictureBox.Name = "card5PictureBox"
        Me.card5PictureBox.Size = New System.Drawing.Size(144, 171)
        Me.card5PictureBox.TabIndex = 13
        Me.card5PictureBox.TabStop = False
        '
        'card4PictureBox
        '
        Me.card4PictureBox.Location = New System.Drawing.Point(631, 124)
        Me.card4PictureBox.Name = "card4PictureBox"
        Me.card4PictureBox.Size = New System.Drawing.Size(149, 171)
        Me.card4PictureBox.TabIndex = 12
        Me.card4PictureBox.TabStop = False
        '
        'card3PictureBox
        '
        Me.card3PictureBox.Location = New System.Drawing.Point(425, 124)
        Me.card3PictureBox.Name = "card3PictureBox"
        Me.card3PictureBox.Size = New System.Drawing.Size(158, 171)
        Me.card3PictureBox.TabIndex = 11
        Me.card3PictureBox.TabStop = False
        '
        'card2PictureBox
        '
        Me.card2PictureBox.Location = New System.Drawing.Point(243, 124)
        Me.card2PictureBox.Name = "card2PictureBox"
        Me.card2PictureBox.Size = New System.Drawing.Size(144, 171)
        Me.card2PictureBox.TabIndex = 10
        Me.card2PictureBox.TabStop = False
        '
        'card1PictureBox
        '
        Me.card1PictureBox.Location = New System.Drawing.Point(57, 124)
        Me.card1PictureBox.Name = "card1PictureBox"
        Me.card1PictureBox.Size = New System.Drawing.Size(139, 171)
        Me.card1PictureBox.TabIndex = 9
        Me.card1PictureBox.TabStop = False
        '
        'dealButton
        '
        Me.dealButton.Location = New System.Drawing.Point(866, 48)
        Me.dealButton.Name = "dealButton"
        Me.dealButton.Size = New System.Drawing.Size(118, 36)
        Me.dealButton.TabIndex = 8
        Me.dealButton.Text = "Deal"
        Me.dealButton.UseVisualStyleBackColor = True
        '
        'shuffleButton
        '
        Me.shuffleButton.Location = New System.Drawing.Point(72, 48)
        Me.shuffleButton.Name = "shuffleButton"
        Me.shuffleButton.Size = New System.Drawing.Size(138, 34)
        Me.shuffleButton.TabIndex = 7
        Me.shuffleButton.Text = "Shuffle"
        Me.shuffleButton.UseVisualStyleBackColor = True
        '
        'CardGame
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1020, 537)
        Me.Controls.Add(Me.card5PictureBox)
        Me.Controls.Add(Me.card4PictureBox)
        Me.Controls.Add(Me.card3PictureBox)
        Me.Controls.Add(Me.card2PictureBox)
        Me.Controls.Add(Me.card1PictureBox)
        Me.Controls.Add(Me.dealButton)
        Me.Controls.Add(Me.shuffleButton)
        Me.Name = "CardGame"
        Me.Text = "Form1"
        CType(Me.card5PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.card4PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.card3PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.card2PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.card1PictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents card5PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents card4PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents card3PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents card2PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents card1PictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents dealButton As System.Windows.Forms.Button
    Friend WithEvents shuffleButton As System.Windows.Forms.Button

End Class
