﻿Public Class CardGame

    Private deck As DeckofCards = New DeckofCards()


    Private Sub shuffleButton_Click(sender As Object, e As EventArgs) Handles shuffleButton.Click

        deck.Shuffle()

        card1PictureBox.Image = Nothing
        card2PictureBox.Image = Nothing
        card3PictureBox.Image = Nothing
        card4PictureBox.Image = Nothing
        card5PictureBox.Image = Nothing
        dealButton.Enabled = True
        MessageBox.Show("Deck is shuffled")
    End Sub

    Private Sub dealButton_Click(sender As Object,
      e As EventArgs) Handles dealButton.Click

        card1PictureBox.Image = GetCardImage(deck.DealCard())
        card2PictureBox.Image = GetCardImage(deck.DealCard())
        card3PictureBox.Image = GetCardImage(deck.DealCard())
        card4PictureBox.Image = GetCardImage(deck.DealCard())
        card5PictureBox.Image = GetCardImage(deck.DealCard())
    End Sub


    Private Function GetCardImage(card As Card) As Image
        If card IsNot Nothing Then

            Dim pictureResource = My.Resources.ResourceManager.GetObject(
              card.ToString().Replace(" ", ""))
            Return CType(pictureResource, Image)
        Else
            dealButton.Enabled = False
            Return Nothing
        End If
    End Function
End Class
