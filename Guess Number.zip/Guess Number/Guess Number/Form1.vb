﻿

'Jared M Kodero

Public Class Form1

    Dim guessNumber As Integer
    Dim number As Integer
    Dim randomNumber As New Random()
    Private Sub TextBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox1.MouseDown
        TextBox1.Text = " "
        Label3.Text = " "
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        guessNumber = randomNumber.Next(100)


        '(Math.Floor((100 - 1 + 1) * Rnd())) + 1

        Button1.Enabled = True
        Button2.Enabled = False


    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        number = Val(TextBox1.Text)

        If number.Equals(guessNumber) Then
            Label3.Text = "Correct!"

            Button2.Enabled = True
            Button1.Enabled = False

        ElseIf number < guessNumber Then
            Label3.Text = "Too low..."
        Else
            Label3.Text = "Too high..."
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button1.Enabled = False
    End Sub



End Class