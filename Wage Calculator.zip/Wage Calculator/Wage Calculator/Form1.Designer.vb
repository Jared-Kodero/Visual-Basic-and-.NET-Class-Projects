﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.wageLabel = New System.Windows.Forms.Label()
        Me.houresLabel = New System.Windows.Forms.Label()
        Me.earnngsLabel = New System.Windows.Forms.Label()
        Me.fwtlabel = New System.Windows.Forms.Label()
        Me.netearningsLabel = New System.Windows.Forms.Label()
        Me.earningsResultLabel = New System.Windows.Forms.Label()
        Me.wageTextBox = New System.Windows.Forms.TextBox()
        Me.hoursTextBox = New System.Windows.Forms.TextBox()
        Me.fwtResultLabel = New System.Windows.Forms.Label()
        Me.netResultLabel = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'wageLabel
        '
        Me.wageLabel.AutoSize = True
        Me.wageLabel.Location = New System.Drawing.Point(12, 23)
        Me.wageLabel.Name = "wageLabel"
        Me.wageLabel.Size = New System.Drawing.Size(94, 17)
        Me.wageLabel.TabIndex = 0
        Me.wageLabel.Text = "Hourly Wage:"
        '
        'houresLabel
        '
        Me.houresLabel.AutoSize = True
        Me.houresLabel.Location = New System.Drawing.Point(12, 72)
        Me.houresLabel.Name = "houresLabel"
        Me.houresLabel.Size = New System.Drawing.Size(100, 17)
        Me.houresLabel.TabIndex = 1
        Me.houresLabel.Text = "Weekly Hours:"
        '
        'earnngsLabel
        '
        Me.earnngsLabel.AutoSize = True
        Me.earnngsLabel.Location = New System.Drawing.Point(12, 115)
        Me.earnngsLabel.Name = "earnngsLabel"
        Me.earnngsLabel.Size = New System.Drawing.Size(109, 17)
        Me.earnngsLabel.TabIndex = 2
        Me.earnngsLabel.Text = "Gross earnings:"
        '
        'fwtlabel
        '
        Me.fwtlabel.AutoSize = True
        Me.fwtlabel.Location = New System.Drawing.Point(12, 152)
        Me.fwtlabel.Name = "fwtlabel"
        Me.fwtlabel.Size = New System.Drawing.Size(76, 17)
        Me.fwtlabel.TabIndex = 3
        Me.fwtlabel.Text = "Less FTW:"
        '
        'netearningsLabel
        '
        Me.netearningsLabel.AutoSize = True
        Me.netearningsLabel.Location = New System.Drawing.Point(12, 187)
        Me.netearningsLabel.Name = "netearningsLabel"
        Me.netearningsLabel.Size = New System.Drawing.Size(93, 17)
        Me.netearningsLabel.TabIndex = 4
        Me.netearningsLabel.Text = "Net earnings:"
        '
        'earningsResultLabel
        '
        Me.earningsResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.earningsResultLabel.Location = New System.Drawing.Point(192, 115)
        Me.earningsResultLabel.Name = "earningsResultLabel"
        Me.earningsResultLabel.Size = New System.Drawing.Size(103, 29)
        Me.earningsResultLabel.TabIndex = 5
        Me.earningsResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'wageTextBox
        '
        Me.wageTextBox.Location = New System.Drawing.Point(195, 23)
        Me.wageTextBox.Name = "wageTextBox"
        Me.wageTextBox.Size = New System.Drawing.Size(100, 22)
        Me.wageTextBox.TabIndex = 8
        '
        'hoursTextBox
        '
        Me.hoursTextBox.Location = New System.Drawing.Point(195, 69)
        Me.hoursTextBox.Name = "hoursTextBox"
        Me.hoursTextBox.Size = New System.Drawing.Size(100, 22)
        Me.hoursTextBox.TabIndex = 9
        '
        'fwtResultLabel
        '
        Me.fwtResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.fwtResultLabel.Location = New System.Drawing.Point(192, 151)
        Me.fwtResultLabel.Name = "fwtResultLabel"
        Me.fwtResultLabel.Size = New System.Drawing.Size(103, 29)
        Me.fwtResultLabel.TabIndex = 10
        Me.fwtResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'netResultLabel
        '
        Me.netResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.netResultLabel.Location = New System.Drawing.Point(192, 187)
        Me.netResultLabel.Name = "netResultLabel"
        Me.netResultLabel.Size = New System.Drawing.Size(103, 29)
        Me.netResultLabel.TabIndex = 11
        Me.netResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(15, 236)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(112, 29)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Clear"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(192, 236)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(103, 29)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Calculate"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.Button2
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(326, 296)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.netResultLabel)
        Me.Controls.Add(Me.fwtResultLabel)
        Me.Controls.Add(Me.hoursTextBox)
        Me.Controls.Add(Me.wageTextBox)
        Me.Controls.Add(Me.earningsResultLabel)
        Me.Controls.Add(Me.netearningsLabel)
        Me.Controls.Add(Me.fwtlabel)
        Me.Controls.Add(Me.earnngsLabel)
        Me.Controls.Add(Me.houresLabel)
        Me.Controls.Add(Me.wageLabel)
        Me.Name = "Form1"
        Me.Text = "Wage Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents wageLabel As System.Windows.Forms.Label
    Friend WithEvents houresLabel As System.Windows.Forms.Label
    Friend WithEvents earnngsLabel As System.Windows.Forms.Label
    Friend WithEvents fwtlabel As System.Windows.Forms.Label
    Friend WithEvents netearningsLabel As System.Windows.Forms.Label
    Friend WithEvents earningsResultLabel As System.Windows.Forms.Label
    Friend WithEvents wageTextBox As System.Windows.Forms.TextBox
    Friend WithEvents hoursTextBox As System.Windows.Forms.TextBox
    Friend WithEvents fwtResultLabel As System.Windows.Forms.Label
    Friend WithEvents netResultLabel As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button

End Class
