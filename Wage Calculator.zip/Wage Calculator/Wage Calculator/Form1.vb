﻿Public Class Form1

    Private Sub earningsResultLabel_TextChanged(sender As Object, e As EventArgs) Handles earningsResultLabel.TextChanged


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        wageTextBox.Text = " "
        hoursTextBox.Text = " "
        earningsResultLabel.Text = " "
        fwtResultLabel.Text = " "
        netResultLabel.Text = " "
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If (wageTextBox.Text <> String.Empty AndAlso
            hoursTextBox.Text <> String.Empty) Then

            Dim hourlyWage As Integer = wageTextBox.Text
            Dim wHours As Integer = hoursTextBox.Text
            Dim grossEarnings As Double

            If wHours > 40 Then
                Dim Overtime As Double = (wHours - 40) * (hourlyWage * 1.5)
                grossEarnings = (hourlyWage * wHours) + Overtime

            Else
                grossEarnings = (hourlyWage * wHours)

            End If

            Dim federalTaxes As Double = (15 / 100) * grossEarnings
            Dim netEarnings As Double = grossEarnings - federalTaxes


            earningsResultLabel.Text = grossEarnings.ToString("C2")
            fwtResultLabel.Text = federalTaxes.ToString("C2")
            netResultLabel.Text = netEarnings.ToString("C2")














        End If

    End Sub
End Class
