﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.accountNumberTextBox = New System.Windows.Forms.TextBox()
        Me.startingBalanceTextBox = New System.Windows.Forms.TextBox()
        Me.totalChargesTextBox = New System.Windows.Forms.TextBox()
        Me.totalcreditsTextBox = New System.Windows.Forms.TextBox()
        Me.creditLimitTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.newBalanceResultLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(117, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Account Number:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 41)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(116, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Starting Balance:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(13, 68)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(101, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Total Charges:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(13, 99)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Total Credits:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(13, 127)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(82, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Credit Limit:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(13, 158)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "New Balance:"
        '
        'Label7
        '
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Location = New System.Drawing.Point(12, 197)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(312, 68)
        Me.Label7.TabIndex = 6
        '
        'accountNumberTextBox
        '
        Me.accountNumberTextBox.Location = New System.Drawing.Point(228, 13)
        Me.accountNumberTextBox.Name = "accountNumberTextBox"
        Me.accountNumberTextBox.Size = New System.Drawing.Size(100, 22)
        Me.accountNumberTextBox.TabIndex = 7
        '
        'startingBalanceTextBox
        '
        Me.startingBalanceTextBox.Location = New System.Drawing.Point(228, 41)
        Me.startingBalanceTextBox.Name = "startingBalanceTextBox"
        Me.startingBalanceTextBox.Size = New System.Drawing.Size(100, 22)
        Me.startingBalanceTextBox.TabIndex = 8
        '
        'totalChargesTextBox
        '
        Me.totalChargesTextBox.Location = New System.Drawing.Point(228, 69)
        Me.totalChargesTextBox.Name = "totalChargesTextBox"
        Me.totalChargesTextBox.Size = New System.Drawing.Size(100, 22)
        Me.totalChargesTextBox.TabIndex = 9
        '
        'totalcreditsTextBox
        '
        Me.totalcreditsTextBox.Location = New System.Drawing.Point(228, 99)
        Me.totalcreditsTextBox.Name = "totalcreditsTextBox"
        Me.totalcreditsTextBox.Size = New System.Drawing.Size(100, 22)
        Me.totalcreditsTextBox.TabIndex = 10
        '
        'creditLimitTextBox
        '
        Me.creditLimitTextBox.Location = New System.Drawing.Point(228, 127)
        Me.creditLimitTextBox.Name = "creditLimitTextBox"
        Me.creditLimitTextBox.Size = New System.Drawing.Size(100, 22)
        Me.creditLimitTextBox.TabIndex = 11
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(164, 288)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(164, 31)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Calculate Balance"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(16, 288)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(116, 31)
        Me.Button2.TabIndex = 14
        Me.Button2.Text = "Clear Fields"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'newBalanceResultLabel
        '
        Me.newBalanceResultLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.newBalanceResultLabel.Location = New System.Drawing.Point(228, 152)
        Me.newBalanceResultLabel.Name = "newBalanceResultLabel"
        Me.newBalanceResultLabel.Size = New System.Drawing.Size(100, 21)
        Me.newBalanceResultLabel.TabIndex = 15
        '
        'Form1
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(332, 360)
        Me.Controls.Add(Me.newBalanceResultLabel)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.creditLimitTextBox)
        Me.Controls.Add(Me.totalcreditsTextBox)
        Me.Controls.Add(Me.totalChargesTextBox)
        Me.Controls.Add(Me.startingBalanceTextBox)
        Me.Controls.Add(Me.accountNumberTextBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents accountNumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents startingBalanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents totalChargesTextBox As System.Windows.Forms.TextBox
    Friend WithEvents totalcreditsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents creditLimitTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents newBalanceResultLabel As System.Windows.Forms.Label

End Class
