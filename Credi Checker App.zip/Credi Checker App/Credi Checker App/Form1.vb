﻿Public Class Form1

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        accountNumberTextBox.Text = String.Empty
        startingBalanceTextBox.Text = String.Empty
        totalChargesTextBox.Text = String.Empty
        totalcreditsTextBox.Text = String.Empty
        creditLimitTextBox.Text = String.Empty
        newBalanceResultLabel.Text = String.Empty
        Label7.Text = String.Empty






    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (accountNumberTextBox.Text <> String.Empty AndAlso startingBalanceTextBox.Text <> String.Empty AndAlso totalChargesTextBox.Text <> String.Empty AndAlso totalcreditsTextBox.Text <> String.Empty AndAlso creditLimitTextBox.Text <> String.Empty) Then

            'initialize variables
            Dim accounNumber As Integer = accountNumberTextBox.Text
            Dim startingBalance As Double = startingBalanceTextBox.Text
            Dim totalCharges As Double = totalChargesTextBox.Text
            Dim totalCredits As Double = totalcreditsTextBox.Text
            Dim creditLimit As Double = creditLimitTextBox.Text

            'calculate balance
            Dim newBalance As Double = startingBalance - totalCredits + totalCharges

            newBalanceResultLabel.Text = String.Format("{0:C}", newBalance)

            'check if new balance > credit Limit
            If (newBalance > creditLimit) Then

                'promt message

                Label7.Text = "You have exceeded" & "credit limit!"

            Else
                Label7.Text = "Remaining credit: " & String.Format("{0:C}", (creditLimit - newBalance))


            End If



        End If




    End Sub
End Class
