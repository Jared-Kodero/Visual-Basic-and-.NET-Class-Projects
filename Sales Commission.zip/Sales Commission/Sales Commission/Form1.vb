﻿Public Class Form1

    'Jared M Kodero

    Dim commission, earnings As Double
    Dim items, gross As Integer


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        items = Val(TextBox1.Text)

        gross = grossSale(items)

        commission = commissionPercentage(items)
        earnings = salesPersonEarnings(gross, commission)

        Label5.Text = gross
        Label6.Text = commission
        Label7.Text = earnings

    End Sub

    'Funtion to calculate gross

    Function grossSale(item As Integer) As Integer
        Return item * 10

    End Function

    'Function to calulate commission %

    Function commissionPercentage(item As Integer) As Integer
        Dim com As Double
        Dim num As Integer

        If item <= 50 Then
            num = 1
        ElseIf item <= 100 Then
            num = 2
        ElseIf item <= 150 Then
            num = 3
        Else
            num = 4

        End If

        Select Case num
            Case 1
                com = 6
            Case 2
                com = 7
            Case 3
                com = 8
            Case 4
                com = 9
        End Select

        Return com

    End Function

    Function salesPersonEarnings(gross As Integer, commission As Integer) As Double
        Dim total As Double

        total = (gross * commission) / 100

        Return total

    End Function

    Private Sub Textbox1_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox1.MouseDown
        TextBox1.Text = " "
        Label5.Text = " "
        Label6.Text = " "
        Label7.Text = " "
    End Sub


End Class
