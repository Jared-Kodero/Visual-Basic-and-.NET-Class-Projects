﻿Public Class Form1

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim miles, gallon, avg, parking, tolls As Integer

        miles = Val(TextBox1.Text)
        gallon = Val(TextBox2.Text)
        avg = Val(TextBox3.Text)
        parking = Val(TextBox4.Text)
        tolls = Val(TextBox5.Text)

        'calculating daily cost
        Label7.Text = (miles * (1 / avg)) * (gallon / 100) + parking + tolls



    End Sub

    Private Sub TextBox1_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox1.MouseDown
        TextBox1.Text = " "
    End Sub
    Private Sub TextBox2_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox2.MouseDown
        TextBox2.Text = " "
    End Sub
    Private Sub TextBox3_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox3.MouseDown
        TextBox3.Text = " "
    End Sub
    Private Sub TextBox4_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox4.MouseDown
        TextBox4.Text = " "
    End Sub
    Private Sub TextBox5_MouseDown(sender As Object, e As MouseEventArgs) Handles TextBox5.MouseDown
        TextBox5.Text = " "
    End Sub
    Private Sub Label7_MouseDown(sender As Object, e As MouseEventArgs) Handles Label7.MouseDown
        Label7.Text = " "
    End Sub

End Class
