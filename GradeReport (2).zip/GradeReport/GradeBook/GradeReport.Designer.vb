﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GradeReport
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
        Me.inputGradesGroupBox = New System.Windows.Forms.GroupBox()
        Me.test3TextBox = New System.Windows.Forms.TextBox()
        Me.test2TextBox = New System.Windows.Forms.TextBox()
        Me.test1TextBox = New System.Windows.Forms.TextBox()
        Me.test3Label = New System.Windows.Forms.Label()
        Me.test2Label = New System.Windows.Forms.Label()
        Me.test1Label = New System.Windows.Forms.Label()
        Me.submitButton = New System.Windows.Forms.Button()
        Me.gradesListBox = New System.Windows.Forms.ListBox()
        Me.classAverageLabel = New System.Windows.Forms.Label()
        Me.gradeViewGroupBox = New System.Windows.Forms.GroupBox()
        Me.LetterCheckBox = New System.Windows.Forms.CheckBox()
        Me.NumericCheckBox = New System.Windows.Forms.CheckBox()
        Me.averageLabel = New System.Windows.Forms.Label()
        Me.barChartListBox = New System.Windows.Forms.ListBox()
        Me.barChartLabel = New System.Windows.Forms.Label()
        Me.inputGradesGroupBox.SuspendLayout()
        Me.gradeViewGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'inputGradesGroupBox
        '
        Me.inputGradesGroupBox.Controls.Add(Me.test3TextBox)
        Me.inputGradesGroupBox.Controls.Add(Me.test2TextBox)
        Me.inputGradesGroupBox.Controls.Add(Me.test1TextBox)
        Me.inputGradesGroupBox.Controls.Add(Me.test3Label)
        Me.inputGradesGroupBox.Controls.Add(Me.test2Label)
        Me.inputGradesGroupBox.Controls.Add(Me.test1Label)
        Me.inputGradesGroupBox.Controls.Add(Me.submitButton)
        Me.inputGradesGroupBox.Location = New System.Drawing.Point(12, 12)
        Me.inputGradesGroupBox.Name = "inputGradesGroupBox"
        Me.inputGradesGroupBox.Size = New System.Drawing.Size(197, 212)
        Me.inputGradesGroupBox.TabIndex = 5
        Me.inputGradesGroupBox.TabStop = False
        Me.inputGradesGroupBox.Text = "Input Grades"
        '
        'test3TextBox
        '
        Me.test3TextBox.Location = New System.Drawing.Point(103, 101)
        Me.test3TextBox.Name = "test3TextBox"
        Me.test3TextBox.Size = New System.Drawing.Size(88, 26)
        Me.test3TextBox.TabIndex = 3
        '
        'test2TextBox
        '
        Me.test2TextBox.Location = New System.Drawing.Point(103, 66)
        Me.test2TextBox.Name = "test2TextBox"
        Me.test2TextBox.Size = New System.Drawing.Size(88, 26)
        Me.test2TextBox.TabIndex = 2
        '
        'test1TextBox
        '
        Me.test1TextBox.Location = New System.Drawing.Point(103, 32)
        Me.test1TextBox.Name = "test1TextBox"
        Me.test1TextBox.Size = New System.Drawing.Size(88, 26)
        Me.test1TextBox.TabIndex = 1
        '
        'test3Label
        '
        Me.test3Label.AutoSize = True
        Me.test3Label.Location = New System.Drawing.Point(24, 104)
        Me.test3Label.Name = "test3Label"
        Me.test3Label.Size = New System.Drawing.Size(50, 20)
        Me.test3Label.TabIndex = 8
        Me.test3Label.Text = "Test 3:"
        '
        'test2Label
        '
        Me.test2Label.AutoSize = True
        Me.test2Label.Location = New System.Drawing.Point(24, 72)
        Me.test2Label.Name = "test2Label"
        Me.test2Label.Size = New System.Drawing.Size(50, 20)
        Me.test2Label.TabIndex = 7
        Me.test2Label.Text = "Test 2:"
        '
        'test1Label
        '
        Me.test1Label.AutoSize = True
        Me.test1Label.Location = New System.Drawing.Point(24, 35)
        Me.test1Label.Name = "test1Label"
        Me.test1Label.Size = New System.Drawing.Size(50, 20)
        Me.test1Label.TabIndex = 6
        Me.test1Label.Text = "Test 1:"
        '
        'submitButton
        '
        Me.submitButton.Location = New System.Drawing.Point(103, 153)
        Me.submitButton.Name = "submitButton"
        Me.submitButton.Size = New System.Drawing.Size(88, 53)
        Me.submitButton.TabIndex = 4
        Me.submitButton.Text = "Submit Grades"
        Me.submitButton.UseVisualStyleBackColor = True
        '
        'gradesListBox
        '
        Me.gradesListBox.FormattingEnabled = True
        Me.gradesListBox.ItemHeight = 19
        Me.gradesListBox.Location = New System.Drawing.Point(286, 23)
        Me.gradesListBox.Name = "gradesListBox"
        Me.gradesListBox.Size = New System.Drawing.Size(496, 156)
        Me.gradesListBox.TabIndex = 7
        '
        'classAverageLabel
        '
        Me.classAverageLabel.AutoSize = True
        Me.classAverageLabel.Location = New System.Drawing.Point(564, 220)
        Me.classAverageLabel.Name = "classAverageLabel"
        Me.classAverageLabel.Size = New System.Drawing.Size(102, 20)
        Me.classAverageLabel.TabIndex = 8
        Me.classAverageLabel.Text = "Class average:"
        '
        'gradeViewGroupBox
        '
        Me.gradeViewGroupBox.Controls.Add(Me.LetterCheckBox)
        Me.gradeViewGroupBox.Controls.Add(Me.NumericCheckBox)
        Me.gradeViewGroupBox.Location = New System.Drawing.Point(12, 269)
        Me.gradeViewGroupBox.Name = "gradeViewGroupBox"
        Me.gradeViewGroupBox.Size = New System.Drawing.Size(197, 104)
        Me.gradeViewGroupBox.TabIndex = 6
        Me.gradeViewGroupBox.TabStop = False
        Me.gradeViewGroupBox.Text = "Grade View"
        '
        'LetterCheckBox
        '
        Me.LetterCheckBox.AutoSize = True
        Me.LetterCheckBox.Location = New System.Drawing.Point(6, 55)
        Me.LetterCheckBox.Name = "LetterCheckBox"
        Me.LetterCheckBox.Size = New System.Drawing.Size(66, 24)
        Me.LetterCheckBox.TabIndex = 3
        Me.LetterCheckBox.Text = "Letter"
        Me.LetterCheckBox.UseVisualStyleBackColor = True
        '
        'NumericCheckBox
        '
        Me.NumericCheckBox.AutoSize = True
        Me.NumericCheckBox.Location = New System.Drawing.Point(6, 25)
        Me.NumericCheckBox.Name = "NumericCheckBox"
        Me.NumericCheckBox.Size = New System.Drawing.Size(84, 24)
        Me.NumericCheckBox.TabIndex = 2
        Me.NumericCheckBox.Text = "Numeric"
        Me.NumericCheckBox.UseVisualStyleBackColor = True
        '
        'averageLabel
        '
        Me.averageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.averageLabel.Font = New System.Drawing.Font("Segoe UI", 12.10619!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.averageLabel.Location = New System.Drawing.Point(672, 203)
        Me.averageLabel.Name = "averageLabel"
        Me.averageLabel.Size = New System.Drawing.Size(110, 48)
        Me.averageLabel.TabIndex = 9
        Me.averageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'barChartListBox
        '
        Me.barChartListBox.Font = New System.Drawing.Font("Lucida Console", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.barChartListBox.FormattingEnabled = True
        Me.barChartListBox.ItemHeight = 14
        Me.barChartListBox.Location = New System.Drawing.Point(274, 292)
        Me.barChartListBox.Name = "barChartListBox"
        Me.barChartListBox.Size = New System.Drawing.Size(508, 298)
        Me.barChartListBox.TabIndex = 10
        '
        'barChartLabel
        '
        Me.barChartLabel.AutoSize = True
        Me.barChartLabel.Location = New System.Drawing.Point(270, 269)
        Me.barChartLabel.Name = "barChartLabel"
        Me.barChartLabel.Size = New System.Drawing.Size(228, 20)
        Me.barChartLabel.TabIndex = 11
        Me.barChartLabel.Text = "Numeric grade distribution chart:"
        '
        'GradeReport
        '
        Me.AcceptButton = Me.submitButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(809, 631)
        Me.Controls.Add(Me.barChartLabel)
        Me.Controls.Add(Me.barChartListBox)
        Me.Controls.Add(Me.inputGradesGroupBox)
        Me.Controls.Add(Me.gradesListBox)
        Me.Controls.Add(Me.classAverageLabel)
        Me.Controls.Add(Me.gradeViewGroupBox)
        Me.Controls.Add(Me.averageLabel)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "GradeReport"
        Me.Text = "Grade Report"
        Me.inputGradesGroupBox.ResumeLayout(False)
        Me.inputGradesGroupBox.PerformLayout()
        Me.gradeViewGroupBox.ResumeLayout(False)
        Me.gradeViewGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
   Friend WithEvents inputGradesGroupBox As System.Windows.Forms.GroupBox
   Friend WithEvents test3TextBox As System.Windows.Forms.TextBox
   Friend WithEvents test2TextBox As System.Windows.Forms.TextBox
   Friend WithEvents test1TextBox As System.Windows.Forms.TextBox
   Friend WithEvents test3Label As System.Windows.Forms.Label
   Friend WithEvents test2Label As System.Windows.Forms.Label
   Friend WithEvents test1Label As System.Windows.Forms.Label
   Friend WithEvents submitButton As System.Windows.Forms.Button
   Friend WithEvents gradesListBox As System.Windows.Forms.ListBox
   Friend WithEvents classAverageLabel As System.Windows.Forms.Label
    Friend WithEvents gradeViewGroupBox As System.Windows.Forms.GroupBox
   Friend WithEvents averageLabel As System.Windows.Forms.Label
   Friend WithEvents barChartListBox As System.Windows.Forms.ListBox
    Friend WithEvents barChartLabel As System.Windows.Forms.Label
    Friend WithEvents LetterCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents NumericCheckBox As System.Windows.Forms.CheckBox

End Class
