﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim k As Integer
        k = Val(TextBox1.Text)

        'Getting last Digit
        Label7.Text = k Mod 10

        'remove last digit
        k = k / 10

        'Getting 4th digit
        Label6.Text = k Mod 10

        'remove last digit
        k = k / 10

        'Getting 3rd Digit
        Label5.Text = k Mod 10
        'remove 3rd digit
        k = k / 10

        'Getting 2nd Digit
        Label4.Text = k Mod 10

        'removing last digit
        k = k / 10

        'Getting 1st Digit

        Label3.Text = k




    End Sub
End Class
